## read RDS

friend_laptop <- readRDS("knnModel.RDS")

## Batch Processing

## Jan 2024 => train model .RDS
## Feb 2024 => train model2 . RDS

